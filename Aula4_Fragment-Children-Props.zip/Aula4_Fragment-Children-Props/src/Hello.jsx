function Hello(props) {
  return <h1>Hello </h1>;
}

export default Hello;
