import "./App.css";
import Hello from "./Hello";
import Nome from "./Nome";

function App() {
  return (
      <Nome nome="Everton" cidade="São Paulo" >
        <Hello/>
        </Nome>
  );
}

export default App;
